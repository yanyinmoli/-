const db = wx.cloud.database();
const twouser = db.collection("twouser");
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    touxiang: 'https://manager.diandianxc.com/diandianxc/mrtx.png',
    icon_r: 'https://manager.diandianxc.com/mine/enter.png',
    sex:[
      {name:'0',value:'男',checked:'true'},
      {name:'1',value:'女'}
    ],
    isSex:"0",
    information:[],
    userSex:'',
    modalHidden:true
  },
  //单选按钮发生变化
  radioChange(e){
    console.log(e.detail.value);
    var sexName=this.data.isSex
    this.setData({
      isSex:e.detail.value
    })
  },
 
  //表单提交
  // formSubmit(e){
  //   console.log(e.detail.value);  
  //   var userSex=this.data.isSex==0?'男':'女';
  //   var information= e.detail.value;
  //   console.log(userSex);
  //   this.setData({
  //     information: e.detail.value,
  //     userSex,
  //     modalHidden:false
  //   });
  // },
  formSubmit: function (res) {
		if (res.detail.value.Username) {
      console.log(res.detail.value)
      // var userSex=this.data.isSex==0?'男':'女';
			//添加数据
			twouser.add({
				data: {
          usename: res.detail.value.Username,
					// sex: userSex,
          password: res.detail.value.Password,
          reskback: res.detail.value.Reskback,
          content:res.detail.value.Content
				}
			}).then(res => {
        console.log(res)
        wx.showToast({
          title: '提交成功',
          icon:'cloud://ck-4g1bxx2x00e7052a.636b-ck-4g1bxx2x00e7052a-1317533034/image/成功.png'
        })
        wx.navigateTo({
          url: '../homepage/homepage',
        })
			})
		} else {
			wx.showToast({
				title: '请输入添加内容',
				icon: "error",
			})
		}
	},

  //模态框取消
  modalCancel(){
    wx.showToast({
      title: '取消提交',
      icon:'none'
    })
    this.setData({
      modalHidden:true,
    })
  },


  //模态框确定
  modalConfirm:function(e) {
    this.setData({ 
    })
    wx.showToast({
      title: '提交成功',
      icon:'success'
    })
    this.setData({
      modalHidden: true
    })
  },

  onLoad: function (options) {

  }
})

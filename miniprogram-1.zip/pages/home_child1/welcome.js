// pages/home—child1/welcome.js
Page({
  Click_SKD:function (){
    wx.navigateTo({
      url: '../SKD/KDquwen',
    })
  },
  Click_SYS:function (){
    wx.navigateTo({
      url: '../SYS/index',
    })
  },
  Click_can:function (){
    wx.navigateTo({
      url: '../can/index',
    })
  },
  Click_ji:function (){
    wx.navigateTo({
      url: '../ji/index',
    })
  },
  Click_xing:function (){
    wx.navigateTo({
      url: '../xing/index',
    })
  },
  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl:'/pages2/animals/cat.png',
    avatarUr2:'/pages2/animals/cat.jpg',
    avatarUr3:'/pages2/animals/cat1.png',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})
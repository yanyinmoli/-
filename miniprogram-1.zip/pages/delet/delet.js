const db = wx.cloud.database();
var dele="";
var dele1="";
var room="";
Page({
  /**
   * 页面的初始数据
   */
  data: {
  },
  dele_oneuser(res){
    var dele1=res.detail.value;
    dele = dele1;
  },
  dele_oneuser1(res){
    var dele2=res.detail.value;
    dele1 = dele2;
  },
  oneadd(){
    wx.navigateTo({
      url: '../oneuseradd/oneuseradd',
    })
  },
  roomupd(res){
    var room1=res.detail.value;
    room = room1;
  },
  getdata(){
    db.collection("oneuser")
    .get()
    .then(res=>{
      this.setData({
        dataArr:res.data
      })
    })
  },
  dele_o(){
    db.collection("oneuser")
    .where({
      'usename':dele
    })
    .remove()
    .then(res=>{
      console.log(res)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  btnNum(){
    db.collection("oneuser")
    .where({
      'usename':dele1
    })
    .update({
      // data 传入需要局部更新的数据
      data: {
        laboratory: room
      },
    })
  },
  onLoad(options) {
    this.getdata();
    db.collection("oneuser").watch({
      onChange:res=>{
        console.log(res)
      },
      onError:err => {
        console.log(err)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})
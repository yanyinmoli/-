// pages/home/home.js
const order = ['demo1', 'demo2', 'demo3']
const db = wx.cloud.database();
var user_name='';
var user_password='';
var s1=[];
Page({
  onShareAppMessage() {
    return {
      title: 'scroll-view',
      path: 'page/component/pages/scroll-view/scroll-view'
    }
  },
  /**
   * 页面的初始数据
   */
  data: {
    toView: 'green'
  },
  getusername: function (e) {
    var dele1=e.detail.value;
    user_name = dele1;
  },
  getpassword:function (e) { 
    var dele1=e.detail.value;
    user_password = dele1;
  },
  getdbcompare(){
  },
  loginClick1:function(){           
    db.collection("oneuser").where({
      'usename':user_name
        }).get().then(res=>{
          var s=res.data;
          s1=s;
          console.log(s1)
        })
      if(s1.length>=1){
        if(s1[0].password==user_password){
          wx.navigateTo({           
          url: '../oupage/oupage',  //url地址
        })}
      else{
        wx.navigateTo({
          url: '../error_page/index',
        })
      }
      }else{
      wx.navigateTo({
        url: '../error_page/index',
      })
      }
},
  loginClick2:function(){            //绑定关键字login：函数function（）{ 执行命令},  
    wx.navigateTo({
      url: '../zhuce/zhuce',
    })
  },
  upper(e) {
    console.log(e)
  },
  lower(e) {
    console.log(e)
  },
  scroll(e) {
    console.log(e)
  },
  scrollToTop() {
    this.setAction({
      scrollTop: 0
    })
  },
  tap() {
    for (let i = 0; i < order.length; ++i) {
      if (order[i] === this.data.toView) {
        this.setData({
          toView: order[i + 1],
          scrollTop: (i + 1) * 200
        })
        break
      }
    }
  },
  tapMove() {
    this.setData({
      scrollTop: this.data.scrollTop + 10
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})
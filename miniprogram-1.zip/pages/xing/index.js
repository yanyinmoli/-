const db = wx.cloud.database();
Page({
  data: {
    information:[],
    modalHidden:true,
    resList:""
  },
  xiugai: function (res){
    if (res.detail.value.num) {
			db.collection("oneuser").doc('93e4b6a0646df5060dc5c79255979c79').update({
        data: {
          usename:res.detail.value.num,
          password:res.detail.value.password,
          laboratory:res.detail.value.sys,
          reskback:res.detail.value.rw,
          request:res.detail.value.xq
        }
      }).then(res=>{
        console.log(res)
      })
      wx.showToast({
        title: '提交成功',
        icon:'cloud://ck-4g1bxx2x00e7052a.636b-ck-4g1bxx2x00e7052a-1317533034/image/成功.png'
      })
    } else {
      		wx.showToast({
      			title: '请输入修改内容',
      			icon: "error",
      		})
      	}
  },

  modalCancel(){
    wx.showToast({
      title: '取消提交',
      icon:'none'
    })
    this.setData({
      modalHidden:true,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    db.collection("oneuser").doc('93e4b6a0646df5060dc5c79255979c79').get()
    .then(res=>{
     console.log({res})
     this.setData({
      resList : res.data
     })
     })  
  },


  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})
  const db = wx.cloud.database();
  const oneuser = db.collection("oneuser");
Page({
  data: {
    },
  onSumnit: function (res) {
    console.log(res.detail.value)
    if (res.detail.value.Usename) {
//添加数据
      oneuser.add({
          data: {
            laboratory: res.detail.value.Laboratory,
            usename: res.detail.value.Usename,
            password: res.detail.value.Password,
            request: res.detail.value.Request,
            reskback: res.detail.value.Reskback
          }
        }).then(res => {
          console.log(res)
        })
        wx.showToast({
          title: '提交成功',
          icon:'cloud://ck-4g1bxx2x00e7052a.636b-ck-4g1bxx2x00e7052a-1317533034/image/成功.png'
        })
      } else {
        wx.showToast({
          title: '添加失败！',
          icon: "error",
        })
      }
    },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})
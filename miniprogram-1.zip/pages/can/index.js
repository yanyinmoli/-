const db = wx.cloud.database();
Page({

  data: {
    das:""
  },
  xiugai: function (res){
    if (res.detail.value.num) {
			db.collection("oneuser").doc('0122a587646cb7700daf92a470c62735').update({
        data: {
          username:res.detail.value.num,
          password:res.detail.value.password,
          laboratory:res.detail.value.sys,
          reskback:res.detail.value.rw,
          request:res.detail.value.xq
        }
      }).then(res=>{
        console.log(res)
      })
    } else {
      		wx.showToast({
      			title: '请输入添加内容',
      			icon: "error",
      		})
      	}
  },

  modalCancel(){
    wx.showToast({
      title: '取消提交',
      icon:'none'
    })
    this.setData({
      modalHidden:true,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad:function(options){
    var a = this
    db.collection("oneuser").doc('0122a587646cb7700daf92a470c62735').get()
  //     success: function(res) {
  //       // res.data 包含该记录的数据
  //       console.log(res)
  //       das.setData({
  //         das:res.data
  //       })
  //       console.log(das)
  //       a.setData({
  //     userList: res.data
  //   })
  //   console.log(das.username)
  //   }
  // })
    .then(res=>{
    this.das=res.data
     console.log(this.das)
     }) 
    
  },


  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})